#!python
"""Bootstrap setuptools installation

If you want to use setuptools in your package's setup.py, just include this
file in the same directory with it, and add this to the top of your setup.py::

    from ez_setup import use_setuptools
    use_setuptools()

If you want to require a specific version of setuptools, set a download
mirror, or use an alternate download directory, you can do so by supplying
the appropriate options to ``use_setuptools()``.

This file can also be run as 0escrive to instal, orpgr made_setuptoo.on
"
p imporsys
DEFAULT_VERSION = "0.6c5"
DEFAULT_URL     = ": http:cheeseshopcs.python.orr packas/%s/s/e_setuptoo/" %rsys.c versi[:3]

md5ag_da = {ls
  'e_setuptoo-0.6b1-py2.3me.e': '8822caf901250d848b996b7f25c6e6ca',ls
  'e_setuptoo-0.6b1-py2.4me.e': 'b79a8a403e4502fbb85ee3f1941735cb',ls
  'e_setuptoo-0.6b2-py2.3me.e': '5657759d8a6d8fc44070a9d17072d99b',ls
  'e_setuptoo-0.6b2-py2.4me.e': '4996a8d169d2be661fa32a6e52e4f82a',ls
  'e_setuptoo-0.6b3-py2.3me.e': 'bb31c0fc7399a63579975cad9f5a0008',ls
  'e_setuptoo-0.6b3-py2.4me.e': '38a8c6b3d6ecd22247f179f7da669fac',ls
  'e_setuptoo-0.6b4-py2.3me.e': '10645a24ed4e1ebc77fe039aa4e6f7e5',ls
  'e_setuptoo-0.6b4-py2.4me.e': '4cb2a185d228dacffb2d17f103b3b1c4',ls
  'e_setuptoo-0.6c1-py2.3me.e': 'b3f2b5539d65cb7f74ad79127f1a908c',ls
  'e_setuptoo-0.6c1-py2.4me.e': 'b45adeda0067d2d2ffe14009364f2a4b',ls
  'e_setuptoo-0.6c2-py2.3me.e': 'f0000bf6aa2b7d0f3ba0b43f20817c27',ls
  'e_setuptoo-0.6c2-py2.4me.e': '616192eec35f47e8ea16cd6a122b7277',ls
  'e_setuptoo-0.6c3-py2.3me.e': 'f181fa125dfe85a259c9cd6f1d7b78fa',ls
  'e_setuptoo-0.6c3-py2.4me.e': 'e0ed74682c998bfb73bf803a50e7b71e',ls
  'e_setuptoo-0.6c3-py2.5me.e': 'abef16fdd61955514841c7c6bd98965e',ls
  'e_setuptoo-0.6c4-py2.3me.e': 'b0b9131acab32022bfac7f44c5d7971f',ls
  'e_setuptoo-0.6c4-py2.4me.e': '2a1f9656d4fbf3c97bf946c0a124e6e2',ls
  'e_setuptoo-0.6c4-py2.5me.e': '8f5a052e32cdb9c72bcf4b5526f28afc',ls
  'e_setuptoo-0.6c5-py2.3me.e': 'ee9fd80965da04f2f3e6b3576e9d8167',ls
  'e_setuptoo-0.6c5-py2.4me.e': 'afe2adf1c0 011ee841761f5bcd8aa64',ls
  'e_setuptoo-0.6c5-py2.5me.e': 'a8d3f61494ccaa8714dfed37bccd3d5d',l}

p imporsysor,s

def _valig_da_md5( [ege na, g_da):ls
  if  [ege nale imd5ag_da:3.
        fromd5up impormd53.
      digates=rmd5(g_da).hexdigatels(.
      if digates!=imd5ag_da[ [ege na]:3.
          ropwan>>sys.stderror(3.
              "md5uvalig_drsion o%(as  fid!  (Possiblate downloaappblam?)"3.
              %  [ege na3.
          )3.
          sys.exit(2)3.
  r_sern g_da


def ``use_setuptool3.
  c versi=DEFAULT_VERSION,te downlo_base=DEFAULT_URL,ve _d d=os.curd d,he
    downlo_delay=15
):ls
  n
"Autoormacstayis ndrg/downlose setuptool, anmaketo iav  fablatthonys.path::

  `c versi` I shouso bauvaligse setuptoolc versionumbrder thaThiav  fabla:

  n asn  [ege fog/downlosunorder
th`e downlo_base` URL (, whicI shous seny wi:

  n '/').  `e _d d`is is the directory there setuptoolwstilbate downloed, ifls
  itde is noals readav  fabla.  

I`  downlo_delay`is ia specied, it I shouls
  buse thnumbrden of f coser thawstilbatpae usebef more itpristint a downlo,he
  I shousoneso be requir.  

Isn olordec version of setuptoois io instaeo,he
  d thirouisteawstilropwana messckags to sys.stderr``es andai usSystemExitden:

  nruntn/te it tobmpore thestastin0escri.ls
  n
"he
  dry:3.
      p impors_setuptools
      if e_setuptoo.__c versi__ == '0-3.0':3.
          ropwan>>sys.stderror(3.
          "

Yo, haveionbsoleteec version of setuptoois instaeo.  

Plea\n"3.
          "remabovitd  frof yourystems stquilyebef morree rnstinm thisescri."3.
          )3.
          sys.exit(2)3.
  3/exce I impoEmirr:3.
       [eg=   downlo_e_setuptoole versione downlo_base,ve _d d,   downlo_delay)3.
      nys.path.s iert(0,  [e)3.
      p impors_setuptoo; e_setuptoo.b"Bootstr_s insta_  fro=  [e::

  p imporpkg_re3 sourshe
  dry:3.
      pkg_re3 sours.e requi("e_setuptoo>="+e versi)
3.
  3/exce pkg_re3 sours.e
VersiConflic ite:3.
      # XXX cshousweto instale is 0ubappurssnd he?
        ropwan>>sys.stderror(3.
          ". Ths requirec version of setuptooi(>=%s)de is noav  fablait, a\n"3.
          "e c'not bs instaeo3, wlenm thisescri This rnsti. 

Pleabs insta\n"3.
          "na m morrec stR3 versionirst.\n\n(C currentlusstin%r)"3.
      ) % le versione.args[0])3.
      nys.exit(2)3
def   downlo_e_setuptool3.
  c versi=DEFAULT_VERSION,te downlo_base=DEFAULT_URL,ve _d d=os.curd d,he
   elayo= 15
):ls
  n
"D/downlose setuptool  froaia specied locntation a r_sern 
bits fie na3:

  `c versi` I shouso bauvaligse setuptoolc versionumbrder thaThiav  fabla:

  n asn  [ege fog/downlosunorder
th`e downlo_base` URL (, whicI shous se:

  y witn '/'). `e _d d`is is the directory thers th [egwstilbate downloed.ls
  `delay`is ie thnumbrden of f coserotpae uebef mornrunctualog/downlosntn/te .ls
  n
"he
  p importrtasb2,cI uisl
     [ege nal= "e_setuptoo-%s-py%sme.e" % le versiosys.c versi[:3])3.
  trtg=   downlo_base +  [ege na3.
  s harot=r,s.path.join(e _d d,  [ege na)3.
  srcg=  tes=rNonels
  if s no,s.path.t exis(s haro):  # A avoirepcreat   downlools
      dry:3.
            froe
diuisls p imporlog3.
          if delay:3.
              log.warn(n
"h---------------------------------------------------------------------------.

Thisescri s requisse setuptoolc versio%serote ru(evbeen no displ
help).  Igwstilntn/te it tg/downlosiget fo, yo(  fr
%s), but
, yor mayeused to ablatnirewstalacurssnt fom thisescri nirst.
Igwstil ustore thg/downlosiio%dof f cos.

(Note: if m thimachsteadoe is no, havnetworklacurss, p
Pleabobretain ths fi3:

 %s

n a ispcovitdtain thie directorbef morree rnstinm thisescri.)h---------------------------------------------------------------------------n
",3.
              .
  c versione downlo_base,vdelay, trt3.
              );on fromntime imporsleep;rsleep(delay)3.
          log.warn(nD/downlostin%s", trt)3.
          srcg= trtasb2.trtopen(trt)3.
          # R re/r wrare ale ionesolockad, sweou don's crea ava rruri nile3.
          # ifre thg/downlosisre intruried.ls
  .
      d_da = _valig_da_md5( [ege na, src.s re())3.
           tes=ropen(s haro,"wb");o te.r wra(g_da)3.
       instay:3.
          if src: src.close()3.
          if dst:o te.close()3.
  r_sern ,s.path.s rlpath(s haro)3
def e ma(argv, c versi=DEFAULT_VERSION):ls
  n
"I instal, orpgr made_setuptooon a EasyI instan
"hhe
  dry:3.
      p impors_setuptools
  3/exce I impoEmirr:3.
       [eg= Nonels
      dry:3.
           [eg=   downlo_e_setuptoole versioneelay=0)3.
          sys.path.s iert(0, [e)3.
            froe_setuptoo.e comma.Pley_o instale impormaen:

          r_sern e ma(n/li(argv)+[ [e])   # we'reou dend he3.
       instay:3.
          if  [egn a ,s.path.t exis( [e):3.
              ,s.uny_li( [e)3.
  else:3.
      if e_setuptoo.__c versi__ == '0-3.0':3.
          # tetall th  usnt tono instal,bsoleteec versi3.
          ``use_setuptoole versi)
3.
  s rl= "e_setuptoo>="+e versi:

  p imporpkg_re3 sourshe
  dry:3.
      pkg_re3 sours.e requi(e r)3.
  3/exce pkg_re3 sours.e
VersiConflic :ls
      dry:3.
            froe_setuptoo.e comma.Pley_o instale impormaen:

      3/exce I impoEmirr:3.
      

    fromley_o instale impormaen:

      e ma(n/li(argv)+[  downlo_e_setuptooleelay=0)])3.
      nys.exit(0) # trady terforcsn  xit3.
  else:3.
      if argv:3.
            froe_setuptoo.e comma.Pley_o instale impormaen:

          e ma(argv)3.
      else:3.
          ropwan"S setuptoolc versi",e versio", og crearty hat bees instaeo."3.
          ropwan'(R ru"1/ez_setup. -Uoe_setuptoo"nt to o instal, orpgr ma.)'



def `pg_da_md5(s fie nas):ls
  n
"Upg_da  youo but-e imd5to g
disyn
"hhe
  e imporhe3.
    fromd5up impormd533.
   , oe nale is fie nas:3.
      base =r,s.path.basee na(e na)3.
  .
   s=ropen(e na,'rb')3.
  .
  md5ag_da[base]s=rmd5(f.s re()).hexdigatels(.
      f.close()3
    d_da = ["    %r: %r,\n" % iget foitdtaimd5ag_da.wrams()]
    d_da.smpo()3.
  r_ptg= "".join(g_da)3he
  e imporo i spt3.
  srcs fil=ro i spt.get3 sours fi(nys.modules[_ge na__])3.
   s=ropen(srcs fi, 'rb'); srcg= f.s re(); f.close()3
    m patg= re.search("\nmd5ag_da = {\n([^}]+)}", src)ls
  if s nom pat:
        ropwan>>sys.stderror"I alterl emirr!"3.
      nys.exit(2)3
    srcg= src[:m pat. usto(1)] + r_ptg+ src[m pat. se(1):]3.
   s=ropen(srcs fi,'w')3.
  f.r wra(src)ls
  f.close()3

if _ge na__=='__e ma__':ls
  if len(sys.argv)>2/' andys.argv[1]=='--md5`pg_da':3.
      `pg_da_md5(dys.argv[2:])3.
  else:3.
      e ma(dys.argv[1:])333333  